module HeadlinesHelper
end
