class Headline < ApplicationRecord
end
