class SubmissionsController < ApplicationController
  before_action :prevent_unauthorized_user_access, only: [:new, :edit ]
    
  
  def index
    @submissions = Submission.all
  end

  def new
    @submission = Submission.new
  end
  
  def create
    @submission = current_user.submissions.new(submission_params)
    
    if @submission.save
      redirect_to root_path, notice: 'Link successfullt created'
    else
      render :new
    end
  end

  def show
    @submission = Submission.find_by(id: params[:id])
    @comments = @submission.comments
  end

  def edit
    submission = Submission.find_by(id: params[:id])
    
    if current_user.owns_submission?(submission)
      @submission = submission
    else
      redirect_to root_path, notice: 'Not authorized to edit this link'
    end
  end
  
  def destroy
    submission = Submission.find_by(id: params[:id])
    
    if current_user.owns_submission?(submission)
      submission.destroy
      redirect_to root_path, notice: 'Link successfully deleted'
    else
      redirect_to root_path, notice: 'Not authorized to deleted this link'
    end
  end
  
  def update
    @submission = current_user.submissions.find_by(id: params[:id])
    
    if @submission.update(submission_params)
      redirect_to root_path, notice: 'Link successfully updated'
    else
      render :edit
    end
  end
  
  private
  
  def submission_params
    params.require(:submission).permit(:title, :url, :description)
  end
  
end
