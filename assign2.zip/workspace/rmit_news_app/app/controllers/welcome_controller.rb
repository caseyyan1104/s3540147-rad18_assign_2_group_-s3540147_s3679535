class WelcomeController < ApplicationController
  def index
    
  end

  def comments
  end

  def submit
  end
end


