require 'test_helper'

class HeadlineTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
