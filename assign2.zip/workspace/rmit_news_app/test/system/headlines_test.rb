require "application_system_test_case"

class HeadlinesTest < ApplicationSystemTestCase
  setup do
    @headline = headlines(:one)
  end

  test "visiting the index" do
    visit headlines_url
    assert_selector "h1", text: "Headlines"
  end

  test "creating a Headline" do
    visit headlines_url
    click_on "New Headline"

    fill_in "Date", with: @headline.date
    fill_in "Info", with: @headline.info
    fill_in "Title", with: @headline.title
    fill_in "User", with: @headline.user
    click_on "Create Headline"

    assert_text "Headline was successfully created"
    click_on "Back"
  end

  test "updating a Headline" do
    visit headlines_url
    click_on "Edit", match: :first

    fill_in "Date", with: @headline.date
    fill_in "Info", with: @headline.info
    fill_in "Title", with: @headline.title
    fill_in "User", with: @headline.user
    click_on "Update Headline"

    assert_text "Headline was successfully updated"
    click_on "Back"
  end

  test "destroying a Headline" do
    visit headlines_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Headline was successfully destroyed"
  end
end
