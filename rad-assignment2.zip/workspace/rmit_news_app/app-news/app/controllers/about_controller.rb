class AboutController < ApplicationController
<<<<<<< HEAD
=======
    def about
    end
>>>>>>> dd914643090603a04b96cbf4685eda2850fb2051
end
