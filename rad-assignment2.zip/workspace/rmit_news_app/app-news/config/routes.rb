Rails.application.routes.draw do

  root 'submissions#index'
  
  resources :submissions, except: :index do
    resources :comments, only: [:create, :edit, :update, :destroy]
  end
  
  get '/newest' => 'submissions#newest', as: :newest_submissions
  
  get '/comments' => 'comments#index'
  
  get '/about' => 'about#about'

  resources :sessions, only: [:new, :create] do
    delete :destroy, on: :collection
  end
  
  resources :users, only: [:new, :create]

end
