class SessionsController < ApplicationController
  before_action :prevent_logged_in_user_access, except: :destroy
  before_action :prevent_unauthorized_user_access, only: :destroy
  
  def new
  end
  
  def create
    user = User.find_by(email: login_params[:email])
    
    if user && user.authenticate(login_params[:password])
      login(user)
      #redirect_to root_path, notice: 'Logged in'
      redirect_back fallback_location: new_session_path, notice: 'Logged in'
    else
      flash.now[:notice] = 'Invalid email/password combination'
      render :new
    end
  end
  
  def destroy
    logout
    #redirect_to root_path, notice: 'Logged out'
    redirect_back fallback_location: new_session_path, notice: 'Logged out'
  end
  
  private
  
  def login_params
    params.require(:session).permit(:email, :password)
  end
  
end
