class AboutController < ApplicationController
    def about
    end
end
