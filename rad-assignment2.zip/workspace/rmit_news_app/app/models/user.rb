class User < ApplicationRecord
    has_secure_password
    has_many :submissions, dependent: :destroy
    has_many :comments
    
    validates :email, presence: true, length: { minimum: 5 }, uniqueness: { case_sensitive: true }
    
    validates :password, length: { minimum: 8 }
    
    def owns_submission?(submission)
        self == submission.user
    end
    
    def owns_comment?(comment)
        self == comment.user
    end
end
